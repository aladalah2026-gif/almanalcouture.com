<?php
require 'config.php';
$hash = password_hash('almanal2026', PASSWORD_DEFAULT);
$db->query("INSERT INTO admin_users (username, password_hash) VALUES ('admin', '$hash')
            ON DUPLICATE KEY UPDATE password_hash='$hash'");
echo "تم إنشاء/تحديث الحساب: admin / almanal2026 — احذفي هذا الملف الآن!";
