<?php
// إعدادات الاتصال بقاعدة البيانات — عدّليها حسب بيانات استضافتك
define('DB_HOST', 'localhost');
define('DB_NAME', 'almanal_couture');
define('DB_USER', 'root');
define('DB_PASS', '');

define('WA_NUMBER', '967783339447'); // واتساب
define('IG_URL', 'https://www.instagram.com/mnoalialqa/');
define('FB_URL', 'https://www.facebook.com/share/19idsFfYvy/');
define('TT_URL', 'https://www.tiktok.com/@mnoali68');
define('TG_URL', 'https://t.me/'); // ضعي رابط قناة تيليجرام

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $db->set_charset('utf8mb4');
} catch (Exception $e) {
    die('تعذر الاتصال بقاعدة البيانات — تحققي من إعدادات config.php');
}
session_start();

function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
