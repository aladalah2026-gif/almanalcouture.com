// ═══ ملف البيانات — لإضافة تصميم جديد انسخي آخر سطر وعدّليه ═══
// img: اسم الصورة داخل مجلد images/ | cat: wedding أو evening أو kids
const WA = '783339447';
const INSTAGRAM = '@mnoalialqa';

const PRODUCTS = [
  {img:"dress-01.jpg", name:"همس الدانتيل", cat:"wedding", desc:"دانتيل فرنسي بأكمام مزهرة وصدرية مطرزة يدوياً", dur:"14–21 يوم"},
  {img:"dress-02.jpg", name:"ليلة العمر", cat:"wedding", desc:"زفاف ملكي بكورسيه وتطريز كريستالي أحمر ذهبي", dur:"14–21 يوم"},
  {img:"dress-03.jpg", name:"الأميرة الفضية", cat:"wedding", desc:"تول فضي مُطرز بالخرز مع أكمام كشكش", dur:"14–21 يوم"},
  {img:"dress-04.jpg", name:"تول الأحلام", cat:"wedding", desc:"دانتيل أبيض وزمرّدي بكتف واحد مطرز", dur:"14–21 يوم"},
  {img:"dress-05.jpg", name:"الليل والورد", cat:"evening", desc:"دانتيل أسود بنصف أكمام مع فيونكة حمراء", dur:"10–14 يوم"},
  {img:"dress-06.jpg", name:"شعلة الحمراء", cat:"evening", desc:"ساتان أحمر بصدرية قلب وطبقات تول كشكش", dur:"10–14 يوم"},
  {img:"dress-07.jpg", name:"قمر الفضة", cat:"evening", desc:"ساتان فضي بلمعة هادئة وتطريز غزير", dur:"10 أيام"},
  {img:"dress-08.jpg", name:"ملكة المخمل", cat:"evening", desc:"مخمل عنابي بتطريز ذهبي وأزرار ملكية", dur:"10–14 يوم"},
  {img:"dress-09.jpg", name:"زمردة الليل", cat:"evening", desc:"قماش زمردي مزخرف بنقشة ذهبية", dur:"10–14 يوم"},
  {img:"dress-10.jpg", name:"نبيذ الكريستال", cat:"evening", desc:"ساتان نبيذي بأكمام منسدلة وتطريز كريستال", dur:"10 أيام"},
  {img:"dress-11.jpg", name:"أميرتنا الصغيرة", cat:"kids", desc:"ثلاثة موديلات: ساتان أحمر، تول بيج، مخمل زيتوني", dur:"7 أيام"},
  {img:"dress-12.jpg", name:"توأم الأميرات", cat:"kids", desc:"مخمل عنابي مذهب — للأم وصغيرتها", dur:"7 أيام"},
  {img:"dress-13.jpg", name:"أناقة صغيرة", cat:"kids", desc:"طقم مدرسي: فيست رمادي بكشكش مع قميص أبيض", dur:"7 أيام"},
  {img:"dress-14.jpg", name:"نجمة المدرسة", cat:"kids", desc:"فست أخضر بياقة بيضاء وأزرار ذهبية", dur:"7 أيام"},
  {img:"dress-15.jpg", name:"دفء الكوردروي", cat:"kids", desc:"كوردروي أخضر مع جاكيت قصير وأزرار لؤلؤية", dur:"7 أيام"},
  {img:"design-01.jpg", name:"وردة الفجر", cat:"wedding", desc:"بلّة باستيل وردية بطبقات تول وأزهار يدوية", dur:"14–21 يوم"},
  {img:"design-02.jpg", name:"سراب اللؤلؤ", cat:"wedding", desc:"قصّة حورية البحر بساتان لؤلؤي مُطرز بالخرز", dur:"14–21 يوم"},
  {img:"design-03.jpg", name:"همس النجوم", cat:"evening", desc:"ساتان كحلي مُرصّع بترتر ذهبي كسماء الليل", dur:"10–14 يوم"},
  {img:"design-04.jpg", name:"رقصة العنبر", cat:"evening", desc:"شيفون ذهبي عنبري متدفق بلمعة احتفالية", dur:"10 أيام"},
  {img:"design-05.jpg", name:"فراشة الحديقة", cat:"kids", desc:"وردي بأجنحة فراشة وطبقات كشكش ناعمة", dur:"7 أيام"},
  {img:"design-06.jpg", name:"قلعة النعناع", cat:"kids", desc:"مينت بمريلة ذهبية وزهور بيضاء", dur:"7 أيام"},
];
