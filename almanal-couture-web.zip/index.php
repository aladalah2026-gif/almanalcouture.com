<?php require 'config.php';
$testis = $db->query("SELECT * FROM testimonials ORDER BY id DESC LIMIT 6"); ?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>المنال كوتور | Almanal Couture — دار الأناقة اليمنية</title>
<meta name="description" content="المنال كوتور — دار يمنية للتصميم والتفصيل الراقي. فساتين زفاف وسهرة وأطفال تُفصَّل يدوياً حسب الطلب. واتساب 783339447">
<meta property="og:title" content="المنال كوتور | Almanal Couture">
<meta property="og:image" content="assets/og.jpg">
<link rel="icon" type="image/png" href="assets/favicon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700;800;900&family=Noto+Naskh+Arabic:wght@600;700&family=Playfair+Display:ital,wght@0,500;0,700;1,500&family=Montserrat:wght@500;600;700&display=swap" rel="stylesheet">
<style>
:root{--gold:#D4AF37;--gold-l:#e8c96a;--gold-d:#b8963a;--char:#141414;--char2:#1e1c19;--blush:#E6C7C2;--ivory:#FAF7F2;--white:#fff}
*{margin:0;padding:0;box-sizing:border-box}
html{scroll-behavior:smooth}
body{font-family:'Tajawal',sans-serif;background:var(--char);color:var(--ivory);line-height:1.8;overflow-x:hidden}
a{text-decoration:none;color:inherit}
img{max-width:100%;display:block}
::selection{background:var(--gold);color:var(--char)}
::-webkit-scrollbar{width:10px}::-webkit-scrollbar-track{background:#0d0d0d}::-webkit-scrollbar-thumb{background:linear-gradient(var(--gold-d),var(--gold));border-radius:10px}

/* ═══ شاشة التحميل ═══ */
#loader{position:fixed;inset:0;background:var(--char);z-index:999;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:22px;transition:opacity .7s,visibility .7s}
#loader.hide{opacity:0;visibility:hidden}
#loader img{width:min(260px,60vw);animation:breathe 2.2s ease-in-out infinite}
@keyframes breathe{0%,100%{transform:scale(1);filter:drop-shadow(0 0 18px rgba(212,175,55,.2))}50%{transform:scale(1.04);filter:drop-shadow(0 0 40px rgba(212,175,55,.45))}}
.loader-bar{width:190px;height:3px;background:#2a2a2a;border-radius:5px;overflow:hidden}
.loader-bar i{display:block;height:100%;width:40%;background:var(--gold);border-radius:5px;animation:load 1.1s ease-in-out infinite}
@keyframes load{0%{transform:translateX(120%)}100%{transform:translateX(-320%)}}

/* ═══ شريط الإعلانات المتحرك ═══ */
.ticker{background:linear-gradient(90deg,#2a2115,#3a2d14,#2a2115);border-bottom:1px solid rgba(212,175,55,.35);overflow:hidden;padding:9px 0;position:relative;z-index:60}
.ticker-track{display:flex;gap:60px;white-space:nowrap;animation:tick 28s linear infinite;width:max-content}
.ticker:hover .ticker-track{animation-play-state:paused}
@keyframes tick{0%{transform:translateX(0)}100%{transform:translateX(50%)}}
.ticker span{color:var(--gold-l);font-size:14px;font-weight:700;display:flex;align-items:center;gap:10px}
.ticker span::before{content:'✦'}

/* ═══ الهيدر الزجاجي ═══ */
header{position:sticky;top:0;z-index:100;background:rgba(16,14,12,.78);backdrop-filter:blur(16px);border-bottom:1px solid rgba(212,175,55,.22)}
.nav{max-width:1280px;margin:auto;display:flex;align-items:center;justify-content:space-between;padding:10px 26px}
.logo img{height:54px;width:auto;transition:.3s}
.logo:hover img{filter:drop-shadow(0 0 14px rgba(212,175,55,.5))}
.nav-links{display:flex;gap:30px;align-items:center;list-style:none}
.nav-links a{color:#ddd6c8;font-size:15px;font-weight:500;position:relative;transition:.3s}
.nav-links a::after{content:'';position:absolute;bottom:-6px;right:0;width:0;height:2px;background:var(--gold);transition:.35s;border-radius:2px}
.nav-links a:hover{color:var(--gold-l)}.nav-links a:hover::after{width:100%}
.nav-cta{background:linear-gradient(135deg,var(--gold),var(--gold-d));color:var(--char)!important;padding:9px 24px;border-radius:30px;font-weight:800!important}
.nav-cta::after{display:none}
.nav-cta:hover{transform:translateY(-2px);box-shadow:0 8px 22px rgba(212,175,55,.4)}
.burger{display:none;color:var(--gold);font-size:27px;background:none;border:none;cursor:pointer}

/* ═══ الواجهة الرئيسية ═══ */
.hero{min-height:96vh;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;position:relative;overflow:hidden;padding:110px 24px 90px;
 background:radial-gradient(ellipse 90% 60% at 50% -10%,rgba(212,175,55,.16),transparent 60%),radial-gradient(ellipse 60% 50% at 85% 90%,rgba(230,199,194,.1),transparent 60%),radial-gradient(ellipse 50% 45% at 8% 75%,rgba(212,175,55,.07),transparent 55%),var(--char)}
.hero-frame{position:absolute;inset:22px;border:1px solid rgba(212,175,55,.28);pointer-events:none}
.hero-frame::before,.hero-frame::after{content:'';position:absolute;width:60px;height:60px;border:2px solid var(--gold)}
.hero-frame::before{top:-2px;right:-2px;border-left:none;border-bottom:none}
.hero-frame::after{bottom:-2px;left:-2px;border-right:none;border-top:none}
.spark{position:absolute;border-radius:50%;background:var(--gold);opacity:0;animation:float linear infinite;pointer-events:none}
@keyframes float{0%{opacity:0;transform:translateY(0) scale(.6)}15%{opacity:.85}85%{opacity:.25}100%{opacity:0;transform:translateY(-95vh) scale(1.1)}}
.hero-logo{width:min(360px,74vw);margin-bottom:8px;animation:heroIn 1.3s ease both;filter:drop-shadow(0 10px 34px rgba(212,175,55,.28))}
@keyframes heroIn{from{opacity:0;transform:translateY(34px)}to{opacity:1;transform:none}}
.hero-kicker{font-family:'Montserrat',sans-serif;letter-spacing:7px;font-size:12px;color:var(--gold);text-transform:uppercase;animation:heroIn 1.3s .2s ease both}
.hero h1{font-size:clamp(26px,4.6vw,48px);font-weight:800;margin:10px 0 4px;animation:heroIn 1.3s .35s ease both}
.hero h1 em{font-style:normal;background:linear-gradient(120deg,var(--gold-l),var(--gold),#f3e2a8,var(--gold-d));-webkit-background-clip:text;background-clip:text;color:transparent;background-size:250% auto;animation:shine 4.5s linear infinite}
@keyframes shine{to{background-position:250% center}}
.hero p{max-width:660px;margin:16px auto 36px;color:#c9c2b3;font-size:clamp(15px,2vw,18.5px);animation:heroIn 1.3s .5s ease both}
.hero-btns{display:flex;gap:18px;justify-content:center;flex-wrap:wrap;animation:heroIn 1.3s .65s ease both}
.btn{display:inline-flex;align-items:center;gap:10px;padding:15px 38px;border-radius:40px;font-weight:800;font-size:16px;transition:.35s;cursor:pointer;border:none;position:relative;overflow:hidden}
.btn-gold{background:linear-gradient(135deg,var(--gold-l),var(--gold-d));color:var(--char)}
.btn-gold::before{content:'';position:absolute;inset:0;background:linear-gradient(115deg,transparent 30%,rgba(255,255,255,.55) 50%,transparent 70%);transform:translateX(-110%);transition:.6s}
.btn-gold:hover::before{transform:translateX(110%)}
.btn-gold:hover{transform:translateY(-3px);box-shadow:0 14px 34px rgba(212,175,55,.45)}
.btn-outline{border:1.5px solid var(--gold);color:var(--gold-l);background:rgba(212,175,55,.06);backdrop-filter:blur(4px)}
.btn-outline:hover{background:var(--gold);color:var(--char);transform:translateY(-3px)}
.hero-stats{display:flex;gap:clamp(24px,6vw,70px);margin-top:56px;animation:heroIn 1.3s .8s ease both;flex-wrap:wrap;justify-content:center}
.hstat{text-align:center}
.hstat b{display:block;font-size:clamp(26px,4vw,40px);color:var(--gold);font-family:'Playfair Display',serif}
.hstat span{font-size:13px;color:#a49d8d}
.scroll-hint{position:absolute;bottom:26px;left:50%;transform:translateX(-50%);color:var(--gold);animation:bob 2s infinite;font-size:20px}
@keyframes bob{0%,100%{transform:translate(-50%,0)}50%{transform:translate(-50%,9px)}}

/* ═══ أقسام عامة ═══ */
section{padding:96px 24px;position:relative}
.container{max-width:1240px;margin:auto}
.sec-head{text-align:center;margin-bottom:60px}
.sec-head .kicker{font-family:'Montserrat',sans-serif;letter-spacing:6px;font-size:11px;color:var(--gold);text-transform:uppercase}
.sec-head h2{font-size:clamp(30px,5vw,50px);font-weight:900;margin-top:10px}
.sec-head .divider{width:76px;height:2px;background:linear-gradient(90deg,transparent,var(--gold),transparent);margin:20px auto 0;position:relative}
.sec-head .divider::after{content:'';position:absolute;right:50%;top:50%;transform:translate(50%,-50%);width:9px;height:9px;background:var(--gold);border-radius:50%;box-shadow:0 0 14px var(--gold)}

/* ═══ الإعلانات/العروض ═══ */
.ads-sec{background:linear-gradient(180deg,var(--char) 0%,#191612 100%);padding-top:80px}
.ads-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:26px}
.ad-card{background:linear-gradient(150deg,#241f17,#1b1812);border:1px solid rgba(212,175,55,.35);border-radius:20px;padding:30px 28px;position:relative;overflow:hidden;transition:.4s}
.ad-card::before{content:'';position:absolute;top:-60%;right:-30%;width:200px;height:200px;background:radial-gradient(circle,rgba(212,175,55,.18),transparent 70%);pointer-events:none}
.ad-card:hover{transform:translateY(-8px);border-color:var(--gold);box-shadow:0 20px 44px rgba(0,0,0,.5)}
.ad-badge{display:inline-block;background:var(--gold);color:var(--char);font-size:12px;font-weight:800;padding:4px 16px;border-radius:20px;margin-bottom:14px}
.ad-card h3{font-size:21px;color:var(--gold-l);margin-bottom:8px}
.ad-card p{color:#c6bfae;font-size:14.5px;min-height:66px}
.ad-link{display:inline-flex;align-items:center;gap:8px;color:var(--gold);font-weight:800;font-size:14.5px;margin-top:14px;transition:.3s}
.ad-link:hover{gap:14px;color:var(--gold-l)}

/* ═══ المجموعات ═══ */
.collections{background:var(--ivory);color:var(--char)}
.collections .sec-head h2{color:var(--char)}
.filters{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-bottom:48px}
.filter-btn{padding:10px 28px;border-radius:30px;border:1.5px solid #d9d2c4;background:#fff;font-family:inherit;font-size:15px;font-weight:700;cursor:pointer;transition:.3s}
.filter-btn.active,.filter-btn:hover{background:var(--char);color:var(--gold);border-color:var(--char)}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:30px}
.card{background:#fff;border-radius:18px;overflow:hidden;box-shadow:0 8px 26px rgba(26,26,26,.08);transition:.45s;display:flex;flex-direction:column;position:relative}
.card:hover{transform:translateY(-10px);box-shadow:0 24px 50px rgba(26,26,26,.18)}
.card-img{height:360px;position:relative;overflow:hidden}
.card-img img{width:100%;height:100%;object-fit:cover;transition:transform .8s cubic-bezier(.2,.8,.2,1)}
.card:hover .card-img img{transform:scale(1.09)}
.card-img::after{content:'';position:absolute;inset:0;background:linear-gradient(180deg,transparent 55%,rgba(20,18,14,.55));opacity:0;transition:.4s}
.card:hover .card-img::after{opacity:1}
.card-img .tag{position:absolute;top:16px;right:16px;background:var(--gold);color:var(--char);font-size:12px;font-weight:800;padding:5px 16px;border-radius:20px;z-index:2}
.card-img .excl{position:absolute;top:16px;left:16px;background:var(--char);color:var(--gold);font-size:11px;font-weight:800;padding:5px 14px;border-radius:20px;z-index:2}
.card-body{padding:22px 22px 26px;display:flex;flex-direction:column;flex:1}
.card-body h3{font-size:19.5px;font-weight:800;margin-bottom:6px}
.card-body p{font-size:14px;color:#6a6a6a;flex:1}
.card-meta{display:flex;justify-content:space-between;align-items:center;margin-top:16px;font-size:13px;color:#8a8a8a}
.order-link{color:var(--gold-d);font-weight:800;cursor:pointer;border:none;background:none;font-family:inherit;font-size:14px;transition:.3s}
.order-link:hover{color:var(--char);letter-spacing:.5px}

/* ═══ كيف نعمل ═══ */
.steps-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:26px}
.step{background:rgba(255,255,255,.028);border:1px solid rgba(212,175,55,.22);border-radius:18px;padding:38px 26px;text-align:center;transition:.4s;position:relative;overflow:hidden}
.step::after{content:'';position:absolute;bottom:0;right:0;left:0;height:3px;background:linear-gradient(90deg,transparent,var(--gold),transparent);transform:scaleX(0);transition:.45s}
.step:hover{border-color:var(--gold);transform:translateY(-6px)}
.step:hover::after{transform:scaleX(1)}
.step-num{width:60px;height:60px;margin:0 auto 20px;border-radius:50%;border:1.5px solid var(--gold);color:var(--gold);font-family:'Playfair Display',serif;display:flex;align-items:center;justify-content:center;font-size:26px;font-style:italic;background:rgba(212,175,55,.07)}
.step h3{font-size:18.5px;margin-bottom:8px;color:var(--gold-l)}
.step p{font-size:14px;color:#bdb6a5}

/* ═══ دليل المقاسات ═══ */
.size-sec{background:var(--ivory);color:var(--char)}
.size-wrap{display:grid;grid-template-columns:1fr 1fr;gap:56px;align-items:center}
.size-box{background:#fff;border-radius:20px;padding:38px;box-shadow:0 10px 36px rgba(26,26,26,.09);border-top:4px solid var(--gold)}
.size-box h3{color:var(--gold-d);margin-bottom:16px;font-size:21px}
.size-row{display:flex;justify-content:space-between;padding:12px 4px;border-bottom:1px dashed #e4ddd2;font-size:15px}
.size-note{margin-top:18px;font-size:13.5px;color:#8a8a8a}
.silhouette{background:linear-gradient(160deg,var(--blush),#f3e3df);border-radius:20px;padding:34px;display:flex;align-items:center;justify-content:center}

/* ═══ آراء العميلات — سلايدر ═══ */
.testi-wrap{overflow:hidden;position:relative}
.testi-track{display:flex;gap:26px;transition:transform .6s cubic-bezier(.2,.8,.2,1)}
.testi{min-width:min(380px,86vw);background:rgba(255,255,255,.03);border:1px solid rgba(212,175,55,.25);border-radius:18px;padding:32px;position:relative}
.testi::before{content:'❝';position:absolute;top:14px;left:22px;font-size:44px;color:rgba(212,175,55,.25);font-family:'Playfair Display',serif}
.testi .stars{color:var(--gold);letter-spacing:3px;margin-bottom:12px}
.testi p{font-size:15px;color:#d4cec0;font-style:italic;margin-bottom:16px}
.testi .who{font-weight:800;font-size:14px;color:var(--ivory)}
.testi .who small{display:block;color:var(--gold);font-weight:600}
.testi-nav{display:flex;gap:12px;justify-content:center;margin-top:30px}
.testi-nav button{width:48px;height:48px;border-radius:50%;border:1.5px solid var(--gold);background:transparent;color:var(--gold);font-size:19px;cursor:pointer;transition:.3s}
.testi-nav button:hover{background:var(--gold);color:var(--char)}

/* ═══ الأسئلة ═══ */
.faq-item{max-width:860px;margin:0 auto 14px;background:rgba(255,255,255,.028);border-radius:14px;overflow:hidden;border:1px solid rgba(212,175,55,.2);transition:.3s}
.faq-item.open{border-color:var(--gold)}
.faq-q{width:100%;text-align:right;padding:21px 28px;background:none;border:none;cursor:pointer;font-family:inherit;font-size:16.5px;font-weight:700;display:flex;justify-content:space-between;align-items:center;gap:12px;color:var(--ivory)}
.faq-q::after{content:'+';color:var(--gold);font-size:23px;font-weight:400;transition:.3s}
.faq-item.open .faq-q::after{transform:rotate(45deg)}
.faq-a{max-height:0;overflow:hidden;transition:max-height .4s ease}
.faq-a p{padding:0 28px 24px;font-size:15px;color:#b5ae9e}

/* ═══ بانر ختامي ═══ */
.banner{background:linear-gradient(135deg,#241b0e,#141210 60%);text-align:center;position:relative;overflow:hidden}
.banner::before{content:'';position:absolute;top:-120px;right:50%;transform:translateX(50%);width:600px;height:300px;background:radial-gradient(ellipse,rgba(212,175,55,.16),transparent 70%)}
.banner h2{font-size:clamp(28px,4.6vw,46px);background:linear-gradient(120deg,var(--gold-l),var(--gold),#f3e2a8);-webkit-background-clip:text;background-clip:text;color:transparent;margin-bottom:16px;position:relative}
.banner p{color:#cfc8b8;max-width:600px;margin:0 auto 34px;position:relative}

/* ═══ الفوتر ═══ */
footer{background:#0d0c0a;padding:80px 24px 34px;color:#9d968a;border-top:1px solid rgba(212,175,55,.18)}
.foot-grid{max-width:1240px;margin:auto;display:grid;grid-template-columns:1.5fr 1fr 1.2fr;gap:48px}
.foot-grid h4{color:var(--gold);margin-bottom:20px;font-size:17.5px}
.foot-grid p,.foot-grid li{font-size:14px}
.foot-grid ul{list-style:none}
.foot-grid li{margin-bottom:12px}
.foot-grid a:hover{color:var(--gold-l)}
.foot-logo{height:96px;width:auto;margin-bottom:16px;filter:drop-shadow(0 4px 16px rgba(212,175,55,.25))}
.socials{display:flex;gap:13px;margin-top:22px;flex-wrap:wrap}
.soc{width:48px;height:48px;border-radius:50%;border:1px solid rgba(212,175,55,.5);display:flex;align-items:center;justify-content:center;transition:.35s}
.soc svg{width:21px;height:21px;fill:#b3ac9c;transition:.35s}
.soc:hover{background:var(--gold);border-color:var(--gold);transform:translateY(-4px);box-shadow:0 10px 22px rgba(212,175,55,.35)}
.soc:hover svg{fill:var(--char)}
.copyright{max-width:1240px;margin:50px auto 0;padding-top:24px;border-top:1px solid #24211b;text-align:center;font-size:13px;color:#6f6a60}

/* ═══ عائم ═══ */
.wa-float{position:fixed;bottom:26px;left:26px;z-index:200;width:62px;height:62px;border-radius:50%;background:#25D366;display:flex;align-items:center;justify-content:center;box-shadow:0 10px 28px rgba(37,211,102,.5);transition:.3s;animation:pulse 2.4s infinite}
.wa-float:hover{transform:scale(1.12)}
.wa-float svg{width:33px;height:33px;fill:#fff}
@keyframes pulse{0%{box-shadow:0 0 0 0 rgba(37,211,102,.5)}70%{box-shadow:0 0 0 19px rgba(37,211,102,0)}100%{box-shadow:0 0 0 0 rgba(37,211,102,0)}}
.to-top{position:fixed;bottom:26px;right:26px;z-index:200;width:48px;height:48px;border-radius:50%;border:1.5px solid var(--gold);background:rgba(20,18,14,.85);color:var(--gold);font-size:20px;cursor:pointer;opacity:0;pointer-events:none;transition:.35s;backdrop-filter:blur(6px)}
.to-top.show{opacity:1;pointer-events:auto}
.to-top:hover{background:var(--gold);color:var(--char)}

/* ═══ نافذة الطلب ═══ */
.modal{display:none;position:fixed;inset:0;z-index:300;background:rgba(10,9,7,.8);backdrop-filter:blur(6px);align-items:center;justify-content:center;padding:20px}
.modal.open{display:flex}
.modal-box{background:var(--ivory);color:var(--char);border-radius:22px;max-width:470px;width:100%;padding:38px 32px;position:relative;border-top:5px solid var(--gold);animation:pop .35s cubic-bezier(.2,.9,.3,1.3)}
@keyframes pop{from{opacity:0;transform:scale(.92) translateY(16px)}to{opacity:1;transform:none}}
.modal-box h3{font-size:22px;margin-bottom:4px}
.modal-box .m-prod{color:var(--gold-d);font-weight:800;font-size:14px;margin-bottom:18px}
.modal-box input,.modal-box textarea{width:100%;padding:13px 15px;margin-bottom:13px;border:1.5px solid #ddd3c0;border-radius:12px;font-family:inherit;font-size:15px;background:#fff;transition:.3s}
.modal-box input:focus,.modal-box textarea:focus{outline:none;border-color:var(--gold);box-shadow:0 0 0 4px rgba(212,175,55,.15)}
.modal-box textarea{min-height:92px;resize:vertical}
.modal-close{position:absolute;top:12px;left:16px;background:none;border:none;font-size:26px;color:#999;cursor:pointer;transition:.3s}
.modal-close:hover{color:var(--char);transform:rotate(90deg)}
.form-ok{text-align:center;padding:30px 10px}
.form-ok .check{width:72px;height:72px;border-radius:50%;background:linear-gradient(135deg,var(--gold-l),var(--gold-d));color:var(--char);font-size:36px;display:flex;align-items:center;justify-content:center;margin:0 auto 18px;animation:pop .5s cubic-bezier(.2,.9,.3,1.4)}

.reveal{opacity:0;transform:translateY(34px);transition:.8s ease}
.reveal.show{opacity:1;transform:none}
@media(max-width:940px){
 .nav-links{position:fixed;inset:0;background:rgba(14,12,10,.98);backdrop-filter:blur(10px);flex-direction:column;justify-content:center;gap:36px;font-size:21px;transform:translateY(-100%);transition:.45s}
 .nav-links.open{transform:none}
 .burger{display:block;z-index:101}
 .size-wrap{grid-template-columns:1fr}
 .foot-grid{grid-template-columns:1fr}
}
</style>
</head>
<body>

<div id="loader"><img src="assets/logo.png" alt="المنال كوتور"><div class="loader-bar"><i></i></div></div>

<!-- شريط إعلانات متحرك -->
<div class="ticker"><div class="ticker-track" id="ticker"></div></div>

<header>
  <nav class="nav">
    <a href="#home" class="logo"><img src="assets/logo.png" alt="المنال كوتور"></a>
    <ul class="nav-links" id="navLinks">
      <li><a href="#collections">المجموعات</a></li>
      <li><a href="#ads">العروض</a></li>
      <li><a href="#steps">كيف نعمل</a></li>
      <li><a href="#size">المقاسات</a></li>
      <li><a href="#faq">الأسئلة</a></li>
      <li><a href="#contact">تواصلي معنا</a></li>
      <li><a class="nav-cta" href="https://wa.me/<?=WA_NUMBER?>" target="_blank">اطلبي الآن ✦</a></li>
    </ul>
    <button class="burger" id="burger" aria-label="القائمة">☰</button>
  </nav>
</header>

<section class="hero" id="home">
  <div class="hero-frame"></div>
  <img class="hero-logo" src="assets/logo.png" alt="المنال كوتور للأزياء">
  <div class="hero-kicker">Haute Couture — Yemen</div>
  <h1>صمِّمي فستانكِ <em>الخاص</em></h1>
  <p>دار يمنية للتصميم والتفصيل الراقي — فساتين زفاف وسهرة وأطفال، تُفصَّل يدوياً بأقمشة فاخرة ودقة قياس تليق بكِ في أجمل مناسباتك.</p>
  <div class="hero-btns">
    <a class="btn btn-gold" href="https://wa.me/<?=WA_NUMBER?>?text=<?=urlencode('مرحباً، أود الاستفسار عن فستان من المنال كوتور')?>" target="_blank">اطلبي عبر واتساب</a>
    <a class="btn btn-outline" href="#collections">شاهدي التصاميم</a>
  </div>
  <div class="hero-stats">
    <div class="hstat"><b data-count="500">0</b><span>فستان تم تسليمه</span></div>
    <div class="hstat"><b data-count="350">0</b><span>عميلة سعيدة</span></div>
    <div class="hstat"><b data-count="6">0</b><span>سنوات خبرة</span></div>
    <div class="hstat"><b data-count="3">0</b><span>دول نشحن إليها</span></div>
  </div>
  <div class="scroll-hint">⌄</div>
</section>

<!-- ═══ الإعلانات والعروض ═══ -->
<section class="ads-sec" id="ads">
  <div class="container">
    <div class="sec-head reveal"><div class="kicker">Offers</div><h2>العروض والإعلانات</h2><div class="divider"></div></div>
    <div class="ads-grid" id="adsGrid"></div>
  </div>
</section>

<!-- ═══ المجموعات ═══ -->
<section class="collections" id="collections">
  <div class="container">
    <div class="sec-head reveal"><div class="kicker">Lookbook</div><h2>مجموعاتنا</h2><div class="divider"></div></div>
    <div class="filters reveal">
      <button class="filter-btn active" data-filter="all">الكل</button>
      <button class="filter-btn" data-filter="wedding">فساتين زفاف</button>
      <button class="filter-btn" data-filter="evening">فساتين سهرة</button>
      <button class="filter-btn" data-filter="kids">فساتين أطفال</button>
    </div>
    <div class="grid" id="grid"></div>
  </div>
</section>

<!-- ═══ كيف نعمل ═══ -->
<section id="steps">
  <div class="container">
    <div class="sec-head reveal"><div class="kicker" style="color:var(--gold)">Made To Measure</div><h2>كيف نعمل</h2><div class="divider"></div></div>
    <div class="steps-grid">
      <div class="step reveal"><div class="step-num">1</div><h3>التواصل</h3><p>راسلينا واتساب وحدّدي المناسبة والموديل الذي أعجبك من معرض أعمالنا.</p></div>
      <div class="step reveal"><div class="step-num">2</div><h3>اختيار القماش</h3><p>نساعدك في اختيار القماش والخامات الأنسب لموديلك ومناسبتك وميزانيتك.</p></div>
      <div class="step reveal"><div class="step-num">3</div><h3>أخذ القياسات</h3><p>دقة متناهية في أخذ القياسات لضمان إتقان التفصيل حسب طبيعة جسمك.</p></div>
      <div class="step reveal"><div class="step-num">4</div><h3>التنفيذ والتسليم</h3><p>تفصيل يدوي متقن خلال 7–21 يوماً حسب الموديل، مع تسليم أنيق في علبتنا الخاصة.</p></div>
    </div>
  </div>
</section>

<!-- ═══ دليل المقاسات ═══ -->
<section class="size-sec" id="size">
  <div class="container">
    <div class="sec-head reveal"><div class="kicker">Size Guide</div><h2>دليل المقاسات</h2><div class="divider"></div></div>
    <div class="size-wrap">
      <div class="size-box reveal">
        <h3>أين تُؤخذ القياسات؟</h3>
        <div class="size-row"><span>محيط الصدر</span><b>أعرض جزء حول الصدر</b></div>
        <div class="size-row"><span>محيط الخصر</span><b>أضيق جزء عند الخصر</b></div>
        <div class="size-row"><span>محيط الأرداف</span><b>أعرض جزء حول الأرداف</b></div>
        <div class="size-row"><span>طول الفستان</span><b>من الكتف حتى الطول المطلوب</b></div>
        <div class="size-row"><span>عرض الأكتاف</span><b>من نقطة كتف إلى الأخرى</b></div>
        <div class="size-row"><span>طول الكم</span><b>من الكتف حتى معصم اليد</b></div>
        <p class="size-note">لا تقلقي إن لم تعرفي قياساتك — نرشدك خطوة بخطوة عبر واتساب، أو نستقبلك في مشغلنا لأخذ القياسات بدقة.</p>
      </div>
      <div class="silhouette reveal">
        <svg viewBox="0 0 220 340" width="200"><path d="M110 30 L82 62 L95 92 L80 310 Q110 330 140 310 L125 92 L138 62 Z" fill="#1A1A1A" stroke="#D4AF37" stroke-width="3"/><line x1="82" y1="130" x2="138" y2="130" stroke="#D4AF37" stroke-dasharray="5 4"/><line x1="88" y1="180" x2="132" y2="180" stroke="#D4AF37" stroke-dasharray="5 4"/><line x1="84" y1="230" x2="136" y2="230" stroke="#D4AF37" stroke-dasharray="5 4"/><text x="150" y="135" font-size="11" fill="#1A1A1A">الصدر</text><text x="150" y="185" font-size="11" fill="#1A1A1A">الخصر</text><text x="150" y="235" font-size="11" fill="#1A1A1A">الأرداف</text></svg>
      </div>
    </div>
  </div>
</section>

<!-- ═══ آراء العميلات ═══ -->
<section>
  <div class="container">
    <div class="sec-head reveal"><div class="kicker">Testimonials</div><h2>قالوا عنّا</h2><div class="divider"></div></div>
    <div class="testi-wrap reveal">
      <div class="testi-track" id="testiTrack">
      <?php while($t=$testis->fetch_assoc()): ?>
        <div class="testi">
          <div class="stars"><?=str_repeat('★',(int)$t['stars'])?></div>
          <p>"<?=e($t['text'])?>"</p>
          <div class="who"><?=e($t['customer_name'])?><small><?=e($t['detail'])?></small></div>
        </div>
      <?php endwhile; ?>
      </div>
    </div>
    <div class="testi-nav reveal">
      <button id="tPrev" aria-label="السابق">‹</button>
      <button id="tNext" aria-label="التالي">›</button>
    </div>
  </div>
</section>

<!-- ═══ الأسئلة ═══ -->
<section id="faq" style="background:var(--char2)">
  <div class="container">
    <div class="sec-head reveal"><div class="kicker">FAQ</div><h2>الأسئلة الشائعة</h2><div class="divider"></div></div>
    <div class="faq-item reveal"><button class="faq-q">كم تستغرق مدة التفصيل؟</button><div class="faq-a"><p>من 7 إلى 21 يوماً حسب نوع الفستان وتعقيد التطريز، ونؤكد لك المدة بدقة عند تأكيد الطلب.</p></div></div>
    <div class="faq-item reveal"><button class="faq-q">هل يمكنني طلب فستان بصورة من تصميم آخر؟</button><div class="faq-a"><p>نعم، أرسلي الصورة عبر واتساب أو تيك توك وسننفذها لك بأقصى درجات الإتقان مع تعديلات تناسب جسمك.</p></div></div>
    <div class="faq-item reveal"><button class="faq-q">ما هي طرق الدفع المتاحة؟</button><div class="faq-a"><p>دفع عند الاستلام داخل المحافظات اليمنية المدعومة، أو تحويلات محلية (جوال كاش، ون كاش، جيب، فلوسك)، وتُحدد التفاصيل عند الطلب.</p></div></div>
    <div class="faq-item reveal"><button class="faq-q">هل يوجد توصيل خارج اليمن؟</button><div class="faq-a"><p>نعم، نشحن لدول الخليج عبر شركات الشحن الدولي، والمدة والتكلفة تُحددان حسب وجهتك.</p></div></div>
    <div class="faq-item reveal"><button class="faq-q">ماذا لو احتاج الفستان تعديلاً؟</button><div class="faq-a"><p>نوفر تعديلاً مجانياً خلال أسبوع من الاستلام لضمان رضاك التام عن إطلالتك.</p></div></div>
  </div>
</section>

<section class="banner">
  <div class="container reveal">
    <h2>مناسبتك القادمة تستحق فستاناً يُفصَّل لكِ وحدك</h2>
    <p>احجزي موعدك الآن — استشارة مجانية ورد سريع خلال دقائق.</p>
    <a class="btn btn-gold" href="https://wa.me/<?=WA_NUMBER?>?text=<?=urlencode('مرحباً، أريد حجز موعد لتفصيل فستان')?>" target="_blank">ابدئي طلبك عبر واتساب</a>
  </div>
</section>

<footer id="contact">
  <div class="foot-grid">
    <div>
      <img class="foot-logo" src="assets/logo.png" alt="المنال كوتور">
      <p>دار يمنية للتصميم والخياطة الراقية — نصنع فساتين الزفاف والسهرة والأطفال يدوياً بحب وإتقان، حسب قياسك وذوقك.</p>
      <div class="socials">
        <a class="soc" href="<?=IG_URL?>" target="_blank" title="Instagram"><svg viewBox="0 0 24 24"><path d="M12 2.2c3.2 0 3.6 0 4.9.1 1.2.1 1.8.2 2.2.4.6.2 1 .5 1.4.9.4.4.7.8.9 1.4.2.4.4 1 .4 2.2.1 1.3.1 1.7.1 4.9s0 3.6-.1 4.9c-.1 1.2-.2 1.8-.4 2.2-.2.6-.5 1-.9 1.4-.4.4-.8.7-1.4.9-.4.2-1 .4-2.2.4-1.3.1-1.7.1-4.9.1s-3.6 0-4.9-.1c-1.2-.1-1.8-.2-2.2-.4-.6-.2-1-.5-1.4-.9-.4-.4-.7-.8-.9-1.4-.2-.4-.4-1-.4-2.2C2.2 15.6 2.2 15.2 2.2 12s0-3.6.1-4.9c.1-1.2.2-1.8.4-2.2.2-.6.5-1 .9-1.4.4-.4.8-.7 1.4-.9.4-.2 1-.4 2.2-.4 1.3-.1 1.7-.1 4.8-.1zM12 0C8.7 0 8.3 0 7 .1 5.8.2 4.9.4 4.1.7c-.8.3-1.4.7-2.1 1.4C1.4 2.7 1 3.4.7 4.1.4 4.9.2 5.8.1 7 0 8.3 0 8.7 0 12s0 3.7.1 5c.1 1.2.3 2.1.6 2.9.3.8.7 1.4 1.4 2.1.6.6 1.3 1 2.1 1.4.8.3 1.7.5 2.9.6 1.3.1 1.7.1 5 .1s3.7 0 5-.1c1.2-.1 2.1-.3 2.9-.6.8-.3 1.4-.7 2.1-1.4.6-.6 1-1.3 1.4-2.1.3-.8.5-1.7.6-2.9.1-1.3.1-1.7.1-5s0-3.7-.1-5c-.1-1.2-.3-2.1-.6-2.9-.3-.8-.7-1.4-1.4-2.1C21.3 1.4 20.6 1 19.9.7c-.8-.3-1.7-.5-2.9-.6C15.7 0 15.3 0 12 0zm0 5.8A6.2 6.2 0 1 0 18.2 12 6.2 6.2 0 0 0 12 5.8zm0 10.2A4 4 0 1 1 16 12a4 4 0 0 1-4 4zm7.9-10.4a1.4 1.4 0 1 1-1.4-1.4 1.4 1.4 0 0 1 1.4 1.4z"/></svg></a>
        <a class="soc" href="<?=TT_URL?>" target="_blank" title="TikTok"><svg viewBox="0 0 24 24"><path d="M19.6 5.8a4.8 4.8 0 0 1-3.5-4.1V1h-3.3v13.6a2.9 2.9 0 1 1-2-2.7V8.5a6.2 6.2 0 1 0 5.3 6.1V8.1a8 8 0 0 0 4.6 1.5V6.3a4.8 4.8 0 0 1-1.1-.5z"/></svg></a>
        <a class="soc" href="<?=FB_URL?>" target="_blank" title="Facebook"><svg viewBox="0 0 24 24"><path d="M24 12a12 12 0 1 0-13.9 11.9v-8.4h-3v-3.5h3V9.4c0-3 1.8-4.7 4.5-4.7a18 18 0 0 1 2.7.2v3h-1.5c-1.5 0-2 .9-2 1.9v2.2h3.4l-.5 3.5h-2.9v8.4A12 12 0 0 0 24 12z"/></svg></a>
        <a class="soc" href="<?=TG_URL?>" target="_blank" title="Telegram"><svg viewBox="0 0 24 24"><path d="M11.9 0A12 12 0 1 0 24 12 12 12 0 0 0 11.9 0zm5.9 8.2-2 9.4c-.1.6-.5.7-1 .4l-3-2.2-1.4 1.4a.7.7 0 0 1-.5.3l.2-3 5.7-5.1c.3-.2 0-.4-.4-.1l-7 4.4-3-1c-.7-.2-.7-.7.1-1l11.7-4.5c.5-.2 1 .1.6 1z"/></svg></a>
        <a class="soc" href="https://wa.me/<?=WA_NUMBER?>" target="_blank" title="WhatsApp"><svg viewBox="0 0 24 24"><path d="M17.5 14.4c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.65.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.5 0 1.47 1.07 2.9 1.22 3.1.15.2 2.11 3.22 5.1 4.51.71.31 1.27.49 1.7.63.72.23 1.37.2 1.88.12.57-.09 1.76-.72 2.01-1.42.25-.7.25-1.29.17-1.42-.07-.12-.27-.2-.57-.35M12.05 21.79h-.01c-1.77 0-3.5-.48-5.01-1.38l-.36-.21-3.73.98 1-3.64-.24-.37a9.86 9.86 0 0 1-1.51-5.26c0-5.45 4.44-9.88 9.89-9.88a9.83 9.83 0 0 1 9.88 9.89c0 5.45-4.44 9.88-9.88 9.88m8.4-18.3A11.8 11.8 0 0 0 12.04 0C5.46 0 .1 5.35.1 11.93c0 2.1.55 4.15 1.6 5.96L.07 24l6.24-1.63a11.93 11.93 0 0 0 5.74 1.46h.01c6.58 0 11.93-5.35 11.93-11.93 0-3.19-1.24-6.19-3.54-8.4"/></svg></a>
      </div>
    </div>
    <div>
      <h4>روابط سريعة</h4>
      <ul>
        <li><a href="#collections">المجموعات</a></li>
        <li><a href="#ads">العروض</a></li>
        <li><a href="#steps">كيف نعمل</a></li>
        <li><a href="#size">دليل المقاسات</a></li>
        <li><a href="#faq">الأسئلة الشائعة</a></li>
      </ul>
    </div>
    <div>
      <h4>تواصلي معنا</h4>
      <ul>
        <li>واتساب/هاتف: <a href="https://wa.me/<?=WA_NUMBER?>" target="_blank" dir="ltr">+967 783 339 447</a></li>
        <li>تيك توك: <a href="<?=TT_URL?>" target="_blank">@mnoali68</a></li>
        <li>انستغرام: <a href="<?=IG_URL?>" target="_blank">@mnoalialqa</a></li>
        <li>فيسبوك: <a href="<?=FB_URL?>" target="_blank">المنال كوتور</a></li>
        <li>الموقع: اليمن — شحن خليجي</li>
      </ul>
    </div>
  </div>
  <div class="copyright">© <?=date('Y')?> المنال كوتور — جميع الحقوق محفوظة | صُنع بحب وإتقان ✦</div>
</footer>

<a class="wa-float" href="https://wa.me/<?=WA_NUMBER?>?text=<?=urlencode('مرحباً')?>" target="_blank" aria-label="WhatsApp">
  <svg viewBox="0 0 24 24"><path d="M17.5 14.4c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.65.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.5 0 1.47 1.07 2.9 1.22 3.1.15.2 2.11 3.22 5.1 4.51.71.31 1.27.49 1.7.63.72.23 1.37.2 1.88.12.57-.09 1.76-.72 2.01-1.42.25-.7.25-1.29.17-1.42-.07-.12-.27-.2-.57-.35M12.05 21.79h-.01c-1.77 0-3.5-.48-5.01-1.38l-.36-.21-3.73.98 1-3.64-.24-.37a9.86 9.86 0 0 1-1.51-5.26c0-5.45 4.44-9.88 9.89-9.88a9.83 9.83 0 0 1 9.88 9.89c0 5.45-4.44 9.88-9.88 9.88m8.4-18.3A11.8 11.8 0 0 0 12.04 0C5.46 0 .1 5.35.1 11.93c0 2.1.55 4.15 1.6 5.96L.07 24l6.24-1.63a11.93 11.93 0 0 0 5.74 1.46h.01c6.58 0 11.93-5.35 11.93-11.93 0-3.19-1.24-6.19-3.54-8.4"/></svg>
</a>
<button class="to-top" id="toTop" aria-label="الأعلى">↑</button>

<div class="modal" id="orderModal">
  <div class="modal-box">
    <button class="modal-close" id="modalClose">×</button>
    <div id="formView">
      <h3>اطلبي تصميمك</h3>
      <div class="m-prod" id="modalProduct"></div>
      <form id="orderForm" method="post" action="order.php">
        <input type="hidden" name="product_name" id="fProductName">
        <input type="text" name="customer_name" placeholder="الاسم الكريم" required>
        <input type="tel" name="phone" placeholder="رقم الهاتف / واتساب" required>
        <textarea name="notes" placeholder="ملاحظات: المناسبة، المقاسات، اللون المفضل..."></textarea>
        <button class="btn btn-gold" style="width:100%;justify-content:center" type="submit">إرسال الطلب ← فتح واتساب</button>
      </form>
    </div>
    <div id="okView" class="form-ok" style="display:none">
      <div class="check">✓</div>
      <h3>تم استلام طلبك!</h3>
      <p style="color:#666;margin:10px 0 20px">سنتواصل معك قريباً — جاري تحويلك لواتساب...</p>
      <a class="btn btn-gold" id="okWa" href="#" target="_blank">متابعة المحادثة في واتساب</a>
    </div>
  </div>
</div>

<script src="products.js"></script>
<script src="ads.js"></script>
<script>
// ═══ شاشة التحميل + شرارات ذهبية ═══
window.addEventListener('load',()=>{
  setTimeout(()=>document.getElementById('loader').classList.add('hide'),900);
  const hero=document.querySelector('.hero');
  for(let i=0;i<26;i++){
    const s=document.createElement('span');s.className='spark';
    const sz=Math.random()*4+2;
    s.style.cssText=`width:${sz}px;height:${sz}px;left:${Math.random()*100}%;bottom:-10px;animation-duration:${Math.random()*9+7}s;animation-delay:${Math.random()*8}s`;
    hero.appendChild(s);
  }
});

// ═══ شريط الإعلانات المتحرك ═══
const actives=(typeof ADS!=='undefined'?ADS:[]).filter(a=>a.active);
const tick=document.getElementById('ticker');
if(actives.length){
  const items=actives.map(a=>`<span>${a.title} — ${a.text}</span>`).join('');
  tick.innerHTML=items+items;
}else{tick.closest('.ticker').style.display='none'}

// ═══ بطاقات الإعلانات ═══
const ag=document.getElementById('adsGrid');
actives.forEach(a=>{
  const c=document.createElement('div');c.className='ad-card reveal';
  c.innerHTML=`<span class="ad-badge">✦ ${a.badge}</span><h3>${a.title}</h3><p>${a.text}</p>
  ${a.link?`<a class="ad-link" href="${a.link}" target="_blank">اكتشفي العرض <b>←</b></a>`:''}`;
  ag.appendChild(c);
});

// ═══ باقي المنطق ═══
const burger=document.getElementById('burger'),navLinks=document.getElementById('navLinks');
burger.addEventListener('click',()=>navLinks.classList.toggle('open'));
navLinks.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>navLinks.classList.remove('open')));

const CATNAMES={wedding:'زفاف',evening:'سهرة',kids:'أطفال'};
const grid=document.getElementById('grid');
PRODUCTS.filter(p=>p.img).forEach(p=>{
  const el=document.createElement('article');
  el.className='card reveal show';el.dataset.cat=p.cat;
  el.innerHTML=`<div class="card-img">
    <img src="images/${p.img}" alt="فستان ${p.name}" loading="lazy">
    ${p.img.startsWith('design-')?'<span class="excl">✦ حصري</span>':''}
    <span class="tag">${CATNAMES[p.cat]}</span></div>
    <div class="card-body"><h3>فستان "${p.name}"</h3><p>${p.desc}</p>
    <div class="card-meta"><span>المدة: ${p.dur}</span>
    <button class="order-link" data-name="فستان ${p.name}">اطلبي هذا الموديل ←</button></div></div>`;
  grid.appendChild(el);
});

document.querySelectorAll('.filter-btn').forEach(btn=>{
  btn.addEventListener('click',()=>{
    document.querySelectorAll('.filter-btn').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    const f=btn.dataset.filter;
    document.querySelectorAll('#grid .card').forEach(c=>{c.style.display=(f==='all'||c.dataset.cat===f)?'flex':'none';});
  });
});

// عدّادات الإحصائيات
const counters=document.querySelectorAll('[data-count]');
const cio=new IntersectionObserver(es=>es.forEach(en=>{
  if(!en.isIntersecting)return;cio.unobserve(en.target);
  const el=en.target,target=+el.dataset.count,t0=performance.now();
  (function step(t){const p=Math.min((t-t0)/1600,1);
    el.textContent=Math.round(target*(1-Math.pow(1-p,3)))+(p===1?'+':'');
    if(p<1)requestAnimationFrame(step);})(t0);
}),{threshold:.5});
counters.forEach(c=>cio.observe(c));

// سلايدر الآراء
const track=document.getElementById('testiTrack');let ti=0;
const tCount=track.children.length;
function tMove(){const w=track.children[0].offsetWidth+26;track.style.transform=`translateX(${ti*w}px)`;}
document.getElementById('tNext').onclick=()=>{ti=Math.max(ti-1,-(tCount-1));tMove();};
document.getElementById('tPrev').onclick=()=>{ti=Math.min(ti+1,0);tMove();};
setInterval(()=>{ti=ti<=-(tCount-1)?0:ti-1;tMove();},4500);

const modal=document.getElementById('orderModal');
document.querySelectorAll('.order-link').forEach(b=>{
  b.addEventListener('click',()=>{
    document.getElementById('modalProduct').textContent=b.dataset.name;
    document.getElementById('fProductName').value=b.dataset.name;
    document.getElementById('formView').style.display='block';
    document.getElementById('okView').style.display='none';
    modal.classList.add('open');
  });
});
document.getElementById('modalClose').addEventListener('click',()=>modal.classList.remove('open'));
modal.addEventListener('click',e=>{if(e.target===modal)modal.classList.remove('open');});
document.getElementById('orderForm').addEventListener('submit',async e=>{
  e.preventDefault();
  const fd=new FormData(e.target);
  try{await fetch('order.php',{method:'POST',body:fd});}catch(err){}
  const name=fd.get('customer_name'),prod=fd.get('product_name'),notes=fd.get('notes');
  const msg=`مرحباً، أنا ${name}\nأود طلب: ${prod}\nملاحظات: ${notes||'—'}`;
  document.getElementById('okWa').href='https://wa.me/<?=WA_NUMBER?>?text='+encodeURIComponent(msg);
  document.getElementById('formView').style.display='none';
  document.getElementById('okView').style.display='block';
  window.open(document.getElementById('okWa').href,'_blank');
});

document.querySelectorAll('.faq-q').forEach(q=>{
  q.addEventListener('click',()=>{
    const item=q.parentElement,a=item.querySelector('.faq-a'),open=item.classList.contains('open');
    document.querySelectorAll('.faq-item').forEach(i=>{i.classList.remove('open');i.querySelector('.faq-a').style.maxHeight=null;});
    if(!open){item.classList.add('open');a.style.maxHeight=a.scrollHeight+'px';}
  });
});

const io=new IntersectionObserver(es=>es.forEach(en=>{if(en.isIntersecting){en.target.classList.add('show');io.unobserve(en.target);}}),{threshold:.1});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));

const toTop=document.getElementById('toTop');
window.addEventListener('scroll',()=>toTop.classList.toggle('show',scrollY>600));
toTop.onclick=()=>scrollTo({top:0,behavior:'smooth'});
</script>
</body>
</html>
