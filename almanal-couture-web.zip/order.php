<?php
require 'config.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php'); exit; }
$name  = trim($_POST['customer_name'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$pname = trim($_POST['product_name'] ?? '');
$notes = trim($_POST['notes'] ?? '');
if ($name === '' || $phone === '') { header('Location: index.php'); exit; }
$stmt = $db->prepare("INSERT INTO orders (customer_name, phone, product_name, notes) VALUES (?,?,?,?)");
$stmt->bind_param('ssss', $name, $phone, $pname, $notes);
$stmt->execute();
http_response_code(200);
echo 'ok';
