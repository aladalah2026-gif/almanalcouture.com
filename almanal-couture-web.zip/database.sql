-- قاعدة بيانات المنال كوتور
CREATE DATABASE IF NOT EXISTS almanal_couture CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE almanal_couture;

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  category ENUM('wedding','evening','kids') NOT NULL,
  description TEXT,
  image VARCHAR(255) DEFAULT '',
  duration VARCHAR(80) DEFAULT '',
  price VARCHAR(80) DEFAULT '',
  featured TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_name VARCHAR(120) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  product_id INT NULL,
  product_name VARCHAR(150) DEFAULT '',
  notes TEXT,
  status ENUM('new','contacted','done','cancelled') DEFAULT 'new',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS testimonials (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_name VARCHAR(120) NOT NULL,
  text TEXT NOT NULL,
  detail VARCHAR(120) DEFAULT '',
  stars TINYINT DEFAULT 5,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS admin_users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(60) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- بيانات تجريبية (يمكن حذفها من لوحة التحكم)
INSERT INTO products (name, category, description, image, duration, featured) VALUES
('فستان "همس الدانتيل"','wedding','دانتيل فرنسي شفاف بأكمام مزهرة وصدرية مطرزة يدوياً مع فيونكة أمامية وخلفية','uploads/dress-01.jpg','14–21 يوماً',1),
('فستان "ليلة العمر"','wedding','فستان زفاف ملكي فاخر بقصّة كورسيه وتطريز كريستالي أحمر ذهبي على تول أبيض','uploads/dress-02.jpg','14–21 يوماً',1),
('فستان "الأميرة الفضية"','wedding','تول فضي مُطرز بالخرز والترتر مع أكمام كشكش وعنق مزخرف بكريستال','uploads/dress-03.jpg','14–21 يوماً',0),
('فستان "تول الأحلام"','wedding','قطعتان من التول والساتان: فستان دانتيل أبيض وآخر زمرّدي بكتف واحد مطرز','uploads/dress-04.jpg','14–21 يوماً',0),
('فستان "الليل والورد"','evening','دانتيل أسود فاخر بنصف أكمام مع فيونكة ساتان حمراء كبيرة','uploads/dress-05.jpg','10–14 يوماً',1),
('فستان "شعلة الحمراء"','evening','ساتان أحمر بصدرية قلب وطبقات تول كشكش متدرجة وذيل طويل','uploads/dress-06.jpg','10–14 يوماً',0),
('فستان "قمر الفضة"','evening','ساتان فضي بلمعة هادئة مع تطريز فضي غزير وتنورة انسيابية','uploads/dress-07.jpg','10 أيام',0),
('فستان "ملكة المخمل"','evening','مخمل عنابي غامق بتطريز ذهبي فاخر وأكمام ساتان بأزرار ملكية','uploads/dress-08.jpg','10–14 يوماً',1),
('فستان "زمردة الليل"','evening','قماش زمردي مزخرف بالنقشة الذهبية وصدرية كورسيه مضيئة','uploads/dress-09.jpg','10–14 يوماً',0),
('فستان "نبيذ الكريستال"','evening','ساتان نبيذي بأكمام منسدلة وتطريز كريستال على الصدر والخصر','uploads/dress-10.jpg','10 أيام',0),
('فستان "أميرتنا الصغيرة"','kids','ثلاثة موديلات: ساتان أحمر بورود، تول بيج بكشكش، ومخمل زيتوني مذهب','uploads/dress-11.jpg','7 أيام',0),
('فستان "توأم الأميرات"','kids','مخمل عنابي مطرز بخيوط ذهبية — موديل للأم ومصغّر لصغيرتك','uploads/dress-12.jpg','7 أيام',0),
('فستان "أناقة صغيرة"','kids','طقم مدرسي أنيق: فيست رمادي بكشكش مع قميص أبيض وفيونكة خلفية','uploads/dress-13.jpg','7 أيام',0),
('فستان "نجمة المدرسة"','kids','فست أخضر بياقة بيضاء وأزرار ذهبية مع فيونكة خلفية — طقم يومي مميز','uploads/dress-14.jpg','7 أيام',0),
('فستان "دفء الكوردروي"','kids','فستان كوردروي أخضر مع جاكيت قصير وأزرار لؤلؤية لإطلالة شتوية','uploads/dress-15.jpg','7 أيام',0);

INSERT INTO testimonials (customer_name, text, detail, stars) VALUES
('أم عبدالرحمن','فستان زفافي تجاوز كل توقعاتي! دقة في التفاصيل وخامة فاخرة، شكري لدار المنال كوتور.','فستان زفاف',5),
('أم سارة','فصلوا فستان بنتي وكان أجمل من الصورة! تعامل راق والتسليم في الموعد.','فساتين أطفال',5),
('نورا ع.','طلبت فستان سهرة عن بعد ووصلني بالضبط كما اتفقنا. احترافية نادرة.','فستان سهرة',5);

-- حساب الدخول للوحة التحكم: المستخدم admin / كلمة المرور almanal2026 (غيّريها بعد أول دخول)
INSERT INTO admin_users (username, password_hash) VALUES
('admin', '$2y$10$wH7Qe3mV0yG0m0yG0m0yG0m0yG0m0yG0m0yG0m0yG0m0yG0m0yG0m0yG');

-- ملاحظة: الهاش أعلاه placeholder — بعد أول رفع، أنشئي حساباً عبر السكربت التالي مرة واحدة:
-- افتحي في المتصفح: yourdomain.com/make_admin.php ثم احذفي الملف فوراً.


-- تصاميم حصرية جديدة
INSERT INTO products (name, category, description, image, duration, featured) VALUES
('فستان "وردة الفجر"','wedding','تصميم حصري: بلّة باستيل وردية بطبقات تول منفوشة وأزهار ثلاثية الأبعاد يدوية الصنع','uploads/design-01.jpg','14–21 يوماً',0),
('فستان "سراب اللؤلؤ"','wedding','تصميم حصري: قصّة حورية البحر بساتان لؤلؤي ومطرز بخرز اللؤلؤ المتدرج','uploads/design-02.jpg','14–21 يوماً',0),
('فستان "همس النجوم"','evening','تصميم حصري: ساتان كحلي عميق مُرصّع بترتر ذهبي يشبه سماء الليل','uploads/design-03.jpg','10–14 يوماً',0),
('فستان "رقصة العنبر"','evening','تصميم حصري: شيفون ذهبي عنبري متدفق بخطوط ضوء ولمعة احتفالية','uploads/design-04.jpg','10 أيام',0),
('فستان "فراشة الحديقة"','kids','تصميم حصري: وردي بأجنحة فراشة كبيرة وطبقات كشكش ناعمة','uploads/design-05.jpg','7 أيام',0),
('فستان "قلعة النعناع"','kids','تصميم حصري: مينت بمريلة ذهبية وزهور بيضاء — إطلالة أميرة صغيرة','uploads/design-06.jpg','7 أيام',0);
