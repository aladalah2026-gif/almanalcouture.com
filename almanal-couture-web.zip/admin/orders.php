<?php
require '../config.php';
if (empty($_SESSION['admin'])) { header('Location: login.php'); exit; }
if ($_SERVER['REQUEST_METHOD']==='POST'){
    $s=$db->prepare("UPDATE orders SET status=? WHERE id=?");
    $s->bind_param('si',$_POST['status'],$_POST['id']); $s->execute(); header('Location: orders.php'); exit;
}
$rows=$db->query("SELECT o.*,p.name pname FROM orders o LEFT JOIN products p ON p.id=o.product_id ORDER BY o.id DESC");
$labels=['new'=>'جديد','contacted'=>'تم التواصل','done'=>'مكتمل','cancelled'=>'ملغي'];
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>الطلبات | المنال كوتور</title><link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;800&display=swap" rel="stylesheet">
<style>
body{font-family:'Tajawal',sans-serif;background:#FAF7F2;margin:0;color:#1A1A1A}
header{background:#1A1A1A;color:#FAF7F2;padding:14px 26px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px}
header a{color:#D4AF37;margin-inline-start:16px;font-size:14px}
.wrap{max-width:1100px;margin:auto;padding:34px 20px}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden}
th,td{padding:11px 13px;text-align:right;border-bottom:1px solid #eee;font-size:14px;vertical-align:top}
th{background:#1A1A1A;color:#D4AF37}
select{padding:6px 10px;border-radius:8px;border:1px solid #ddd;font-family:inherit}
a.wa{color:#128c4b;font-weight:700}
</style></head><body>
<header><div><b>الطلبات</b></div>
<div><a href="index.php">الرئيسية</a><a href="products.php">المنتجات</a><a href="logout.php">خروج ⏻</a></div></header>
<div class="wrap">
<table><tr><th>#</th><th>الاسم</th><th>الهاتف</th><th>المنتج</th><th>ملاحظات</th><th>الحالة</th><th>التاريخ</th></tr>
<?php while($o=$rows->fetch_assoc()):?>
<tr><td><?=$o['id']?></td><td><?=e($o['customer_name'])?></td>
<td dir="ltr"><a class="wa" href="https://wa.me/<?=preg_replace('/\D/','',e($o['phone']))?>" target="_blank"><?=e($o['phone'])?> واتساب</a></td>
<td><?=e($o['pname']??'استفسار عام')?></td><td><?=e($o['notes'])?></td>
<td><form method="post" style="display:flex;gap:6px"><input type="hidden" name="id" value="<?=$o['id']?>">
<select name="status"><?php foreach($labels as $k=>$v):?><option value="<?=$k?>" <?=$o['status']===$k?'selected':''?>><?=$v?></option><?php endforeach;?></select>
<button style="padding:6px 14px;font-size:13px">حفظ</button></form></td>
<td style="white-space:nowrap"><?=$o['created_at']?></td></tr>
<?php endwhile;?></table>
</div></body></html>