<?php
require '../config.php';
if (empty($_SESSION['admin'])) { header('Location: login.php'); exit; }
$cats=['wedding'=>'زفاف','evening'=>'سهرة','kids'=>'أطفال'];
// delete
if (isset($_GET['del'])) { $s=$db->prepare("DELETE FROM products WHERE id=?"); $s->bind_param('i',$_GET['del']); $s->execute(); header('Location: products.php'); exit; }
// add / edit
if ($_SERVER['REQUEST_METHOD']==='POST'){
    $id=(int)($_POST['id']??0);
    $name=trim($_POST['name']); $cat=$_POST['category']; $desc=trim($_POST['description']); $dur=trim($_POST['duration']);
    $img=$_POST['old_image']??'';
    if (!empty($_FILES['image']['name'])){
        $ext=strtolower(pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION));
        if (in_array($ext,['jpg','jpeg','png','webp','svg'])){
            $img='uploads/'.time().'_'.preg_replace('/[^a-zA-Z0-9_.]/','_',$_FILES['image']['name']);
            move_uploaded_file($_FILES['image']['tmp_name'],'../'.$img);
        }
    }
    if ($id){ $s=$db->prepare("UPDATE products SET name=?,category=?,description=?,duration=?,image=? WHERE id=?");
        $s->bind_param('sssssi',$name,$cat,$desc,$dur,$img,$id);
    } else { $s=$db->prepare("INSERT INTO products (name,category,description,duration,image) VALUES (?,?,?,?,?)");
        $s->bind_param('sssss',$name,$cat,$desc,$dur,$img);
    }
    $s->execute(); header('Location: products.php'); exit;
}
$edit=null;
if (isset($_GET['edit'])){ $s=$db->prepare("SELECT * FROM products WHERE id=?"); $s->bind_param('i',$_GET['edit']); $s->execute(); $edit=$s->get_result()->fetch_assoc(); }
$rows=$db->query("SELECT * FROM products ORDER BY id DESC");
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>المنتجات | المنال كوتور</title><link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;800&display=swap" rel="stylesheet">
<style>
body{font-family:'Tajawal',sans-serif;background:#FAF7F2;margin:0;color:#1A1A1A}
header{background:#1A1A1A;color:#FAF7F2;padding:14px 26px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px}
header a{color:#D4AF37;margin-inline-start:16px;font-size:14px}
.wrap{max-width:1100px;margin:auto;padding:34px 20px}
form{background:#fff;border-radius:14px;padding:26px;box-shadow:0 4px 18px rgba(0,0,0,.06);margin-bottom:30px}
input,select,textarea{width:100%;padding:11px 13px;margin-bottom:12px;border:1px solid #ddd;border-radius:9px;font-family:inherit;font-size:14px}
button{background:#D4AF37;border:none;border-radius:9px;padding:11px 30px;font-family:inherit;font-weight:800;font-size:15px;cursor:pointer}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden}
th,td{padding:11px 13px;text-align:right;border-bottom:1px solid #eee;font-size:14px}
th{background:#1A1A1A;color:#D4AF37}
td img{width:52px;height:52px;object-fit:cover;border-radius:8px}
a{color:#b8963a;font-weight:700}
.del{color:#c0392b}
</style></head><body>
<header><div><b>المنتجات</b></div>
<div><a href="index.php">الرئيسية</a><a href="orders.php">الطلبات</a><a href="ads.php">📢 إعلانات</a><a href="sync.php">⚡ مزامنة</a><a href="testimonials.php">الآراء</a><a href="logout.php">خروج ⏻</a></div></header>
<div class="wrap">
<form method="post" enctype="multipart/form-data">
<h3><?=$edit?'تعديل منتج':'إضافة منتج جديد'?></h3>
<input type="hidden" name="id" value="<?=$edit['id']??''?>">
<input type="hidden" name="old_image" value="<?=$edit['image']??''?>">
<input name="name" placeholder="اسم الفستان" required value="<?=e($edit['name']??'')?>">
<select name="category"><?php foreach($cats as $k=>$v):?><option value="<?=$k?>" <?=($edit['category']??'')===$k?'selected':''?>><?=$v?></option><?php endforeach;?></select>
<textarea name="description" placeholder="الوصف"><?=e($edit['description']??'')?></textarea>
<input name="duration" placeholder="مدة التنفيذ (مثال: 10–14 يوماً)" value="<?=e($edit['duration']??'')?>">
<input type="file" name="image" accept="image/*">
<button><?=$edit?'حفظ التعديلات':'إضافة'?></button> <?php if($edit):?><a href="products.php">إلغاء</a><?php endif;?>
</form>
<table><tr><th>صورة</th><th>الاسم</th><th>القسم</th><th>المدة</th><th>إجراءات</th></tr>
<?php while($r=$rows->fetch_assoc()):?>
<tr><td><img src="../<?=e($r['image'])?>"></td><td><?=e($r['name'])?></td><td><?=$cats[$r['category']]?></td><td><?=e($r['duration'])?></td>
<td><a href="?edit=<?=$r['id']?>">تعديل</a> | <a class="del" href="?del=<?=$r['id']?>" onclick="return confirm('حذف المنتج؟')">حذف</a></td></tr>
<?php endwhile;?></table>
</div></body></html>