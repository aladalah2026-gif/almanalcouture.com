<?php
require '../config.php';
if (empty($_SESSION['admin'])) { header('Location: login.php'); exit; }
$msg='';
$path='../ads.js';
if ($_SERVER['REQUEST_METHOD']==='POST'){
    file_put_contents($path, $_POST['content']);
    $msg='تم حفظ الإعلانات ✓ — التحديث يظهر في الموقع فوراً';
}
$content=@file_get_contents($path);
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>إدارة الإعلانات | المنال كوتور</title><link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;800&display=swap" rel="stylesheet">
<style>
body{font-family:'Tajawal',sans-serif;background:#FAF7F2;margin:0;color:#1A1A1A}
header{background:#1A1A1A;color:#FAF7F2;padding:14px 26px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px}
header a{color:#D4AF37;margin-inline-start:16px;font-size:14px}
.wrap{max-width:860px;margin:auto;padding:36px 20px}
.card{background:#fff;border-radius:16px;padding:30px;box-shadow:0 4px 18px rgba(0,0,0,.06);border-top:4px solid #D4AF37}
h3{margin-bottom:6px}p{color:#666;font-size:14px;margin-bottom:18px;line-height:1.9}
textarea{width:100%;min-height:340px;padding:16px;border:2px solid #e5dcc8;border-radius:12px;font-family:monospace;font-size:13.5px;direction:ltr;text-align:left;background:#fffdf6;resize:vertical}
button{background:#D4AF37;border:none;border-radius:10px;padding:13px 40px;font-family:inherit;font-weight:800;font-size:16px;cursor:pointer;margin-top:16px}
.msg{background:#d5f5e3;color:#196f3d;padding:13px 20px;border-radius:12px;font-weight:700;margin-bottom:20px}
.tip{background:#fdf3d7;border-radius:10px;padding:14px 18px;font-size:13.5px;color:#7a6514;margin-bottom:18px;line-height:2}
code{background:#f0ead9;padding:1px 7px;border-radius:6px}
</style></head><body>
<header><div><b>إدارة الإعلانات والعروض</b></div>
<div><a href="index.php">الرئيسية</a><a href="sync.php">⚡ مزامنة</a><a href="orders.php">الطلبات</a><a href="logout.php">خروج ⏻</a></div></header>
<div class="wrap">
<?php if($msg):?><div class="msg"><?=$msg?></div><?php endif;?>
<div class="card">
<h3>📢 إعلانات الصفحة الرئيسية</h3>
<p>كل إعلان = سطر بين قوسين. التعديل هنا يظهر في الموقع فور الحفظ.</p>
<div class="tip">✦ <code>active:true</code> يعرض الإعلان | <code>active:false</code> يخفيه (للاحتفاظ به لوقت لاحق)<br>
✦ <code>link</code> ضعي رابط واتساب — اتركيه <code>""</code> لعرض الإعلان بدون زر<br>
✦ يمكنك إضافة أي عدد من الإعلانات — انسخي سطراً كاملاً وعدّليه</div>
<form method="post"><textarea name="content"><?=e($content)?></textarea>
<button>💾 حفظ الإعلانات</button></form>
</div></div></body></html>
