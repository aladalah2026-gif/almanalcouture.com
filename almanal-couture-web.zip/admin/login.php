<?php
require '../config.php';
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST'){
    $u=trim($_POST['username']??''); $p=$_POST['password']??'';
    $s=$db->prepare("SELECT * FROM admin_users WHERE username=?"); $s->bind_param('s',$u); $s->execute();
    $row=$s->get_result()->fetch_assoc();
    if ($row && password_verify($p,$row['password_hash'])){ $_SESSION['admin']=$row['id']; header('Location: index.php'); exit; }
    $error='بيانات الدخول غير صحيحة';
}
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>دخول لوحة التحكم | المنال كوتور</title>
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;800&display=swap" rel="stylesheet">
<style>body{font-family:'Tajawal',sans-serif;background:#1A1A1A;min-height:100vh;display:flex;align-items:center;justify-content:center;margin:0}
.box{background:#FAF7F2;border-radius:16px;padding:40px 34px;width:min(400px,90vw);border-top:4px solid #D4AF37;text-align:center}
.box img{height:70px;margin:0 auto 14px}.box h2{margin-bottom:24px}
input{width:100%;padding:12px 14px;margin-bottom:14px;border:1px solid #ddd;border-radius:10px;font-family:inherit;font-size:15px}
button{width:100%;padding:13px;background:#D4AF37;border:none;border-radius:10px;font-family:inherit;font-weight:800;font-size:16px;cursor:pointer}
.err{color:#c0392b;font-size:14px;margin-bottom:12px}</style></head>
<body><div class="box">
<img src="../assets/logo.png" alt="المنال كوتور"><h2>لوحة التحكم</h2>
<?php if($error):?><div class="err"><?=e($error)?></div><?php endif;?>
<form method="post"><input name="username" placeholder="اسم المستخدم" required><input type="password" name="password" placeholder="كلمة المرور" required><button>دخول</button></form>
</div></body></html>