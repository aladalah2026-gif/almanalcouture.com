<?php
require '../config.php';
if (empty($_SESSION['admin'])) { header('Location: login.php'); exit; }
$stats=[
 'products'=>$db->query("SELECT COUNT(*) c FROM products")->fetch_assoc()['c'],
 'orders_new'=>$db->query("SELECT COUNT(*) c FROM orders WHERE status='new'")->fetch_assoc()['c'],
 'orders_total'=>$db->query("SELECT COUNT(*) c FROM orders")->fetch_assoc()['c'],
 'testimonials'=>$db->query("SELECT COUNT(*) c FROM testimonials")->fetch_assoc()['c'],
];
$latest=$db->query("SELECT o.*,p.name pname FROM orders o LEFT JOIN products p ON p.id=o.product_id ORDER BY o.id DESC LIMIT 8");
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>لوحة التحكم | المنال كوتور</title><link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;800&display=swap" rel="stylesheet">
<style>
body{font-family:'Tajawal',sans-serif;background:#FAF7F2;margin:0;color:#1A1A1A}
header{background:#1A1A1A;color:#FAF7F2;padding:14px 26px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px}
header a{color:#D4AF37;margin-inline-start:16px;font-size:14px}
.wrap{max-width:1100px;margin:auto;padding:34px 20px}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:18px;margin-bottom:34px}
.card{background:#fff;border-radius:14px;padding:24px;box-shadow:0 4px 18px rgba(0,0,0,.06);border-top:3px solid #D4AF37}
.card b{font-size:34px;color:#b8963a;display:block}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden}
th,td{padding:12px 14px;text-align:right;border-bottom:1px solid #eee;font-size:14px}
th{background:#1A1A1A;color:#D4AF37}
.badge{padding:3px 12px;border-radius:20px;font-size:12px;font-weight:700}
.b-new{background:#fdebd0;color:#b9770e}.b-contacted{background:#d6eaf8;color:#1a5276}.b-done{background:#d5f5e3;color:#196f3d}.b-cancelled{background:#fadbd8;color:#922b21}
</style></head><body>
<header><div><b>المنال كوتور — لوحة التحكم</b></div>
<div><a href="products.php">المنتجات</a><a href="orders.php">الطلبات</a><a href="ads.php">📢 إعلانات</a><a href="sync.php">⚡ مزامنة</a><a href="testimonials.php">الآراء</a><a href="logout.php">خروج ⏻</a></div></header>
<div class="wrap">
<div class="cards">
 <div class="card">المنتجات<b><?=$stats['products']?></b></div>
 <div class="card">طلبات جديدة<b><?=$stats['orders_new']?></b></div>
 <div class="card">إجمالي الطلبات<b><?=$stats['orders_total']?></b></div>
 <div class="card">آراء العميلات<b><?=$stats['testimonials']?></b></div>
</div>
<h3>أحدث الطلبات</h3>
<table><tr><th>#</th><th>الاسم</th><th>الهاتف</th><th>المنتج</th><th>الحالة</th><th>التاريخ</th></tr>
<?php while($o=$latest->fetch_assoc()):
 $b=['new'=>'جديد','contacted'=>'تم التواصل','done'=>'مكتمل','cancelled'=>'ملغي'][$o['status']];?>
<tr><td><?=$o['id']?></td><td><?=e($o['customer_name'])?></td><td dir="ltr"><?=e($o['phone'])?></td><td><?=e($o['pname']??'استفسار عام')?></td>
<td><span class="badge b-<?=$o['status']?>"><?=$b?></span></td><td><?=$o['created_at']?></td></tr>
<?php endwhile;?></table>
<p style="margin-top:22px"><a href="orders.php" style="color:#b8963a;font-weight:700">عرض كل الطلبات ←</a></p>
</div></body></html>