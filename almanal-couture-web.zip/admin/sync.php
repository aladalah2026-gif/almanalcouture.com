<?php
require '../config.php';
if (empty($_SESSION['admin'])) { header('Location: login.php'); exit; }
$msg='';
// رفع صور جديدة إلى images/
if (!empty($_FILES['images']['name'][0])){
    $n=0;
    foreach($_FILES['images']['name'] as $i=>$nm){
        $ext=strtolower(pathinfo($nm,PATHINFO_EXTENSION));
        if(!in_array($ext,['jpg','jpeg','png','webp'])) continue;
        $dst='../images/'.preg_replace('/[^a-zA-Z0-9_.-]/','_',$_FILES['images']['name'][$i]);
        if(move_uploaded_file($_FILES['images']['tmp_name'][$dst? $i:$i],$dst)) $n++;
    }
    $msg="تم رفع $n صورة ✓";
}
// رفع products.js جديد
if (!empty($_FILES['datafile']['name'])){
    if (move_uploaded_file($_FILES['datafile']['tmp_name'],'../products.js'))
        $msg='تم تحديث products.js ✓';
}
// مزامنة: نقل صور من uploads إلى images + إعادة بناء جدول المنتجات من products.js
if (isset($_POST['sync'])){
    $js=@file_get_contents('../products.js');
    $rows=[];
    preg_match_all('/\{img:"([^"]+)",\s*name:"([^"]+)",\s*cat:"(wedding|evening|kids)",\s*desc:"([^"]*)",\s*dur:"([^"]*)"\}/u',$js,$m,PREG_SET_ORDER);
    foreach($m as $r){
        // نقل الصورة من uploads إن وُجدت هناك
        if(file_exists('../uploads/'.$r[1]) && !file_exists('../images/'.$r[1]))
            @copy('../uploads/'.$r[1],'../images/'.$r[1]);
        $rows[]=['img'=>$r[1],'name'=>$r[2],'cat'=>$r[3],'desc'=>$r[4],'dur'=>$r[5]];
    }
    $db->query("DELETE FROM products");
    $s=$db->prepare("INSERT INTO products (name,category,description,image,duration,featured) VALUES (?,?,?,?,?,0)");
    foreach($rows as $r){ $img='images/'.$r['img'];
        $s->bind_param('sssss',$r['name'],$r['cat'],$r['desc'],$img,$r['dur']); $s->execute(); }
    $msg='تمت المزامنة: '.count($rows).' موديلاً ✓ (الموقع محدّث الآن)';
}
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>مزامنة التصاميم | المنال كوتور</title><link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;800&display=swap" rel="stylesheet">
<style>
body{font-family:'Tajawal',sans-serif;background:#FAF7F2;margin:0;color:#1A1A1A}
header{background:#1A1A1A;color:#FAF7F2;padding:14px 26px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px}
header a{color:#D4AF37;margin-inline-start:16px;font-size:14px}
.wrap{max-width:760px;margin:auto;padding:36px 20px}
.card{background:#fff;border-radius:16px;padding:30px;box-shadow:0 4px 18px rgba(0,0,0,.06);margin-bottom:24px;border-top:4px solid #D4AF37}
h3{margin-bottom:8px}p{color:#666;font-size:14.5px;margin-bottom:16px}
input[type=file]{width:100%;padding:14px;border:2px dashed #D4AF37;border-radius:12px;margin-bottom:14px;font-family:inherit;background:#fffdf7}
button{background:#D4AF37;border:none;border-radius:10px;padding:12px 34px;font-family:inherit;font-weight:800;font-size:15px;cursor:pointer}
.msg{background:#d5f5e3;color:#196f3d;padding:13px 20px;border-radius:12px;font-weight:700;margin-bottom:20px}
.sync{background:#1A1A1A;color:#FAF7F2}
.sync button{background:#D4AF37;color:#1A1A1A;width:100%;padding:15px;font-size:17px}
ol{padding-right:22px;color:#555;font-size:14.5px;line-height:2}
</style></head><body>
<header><div><b>مزامنة التصاميم</b></div>
<div><a href="index.php">الرئيسية</a><a href="products.php">المنتجات</a><a href="ads.php">📢 إعلانات</a><a href="orders.php">الطلبات</a><a href="logout.php">خروج ⏻</a></div></header>
<div class="wrap">
<?php if($msg):?><div class="msg"><?=e($msg)?></div><?php endif;?>

<div class="card">
<h3>📤 الخطوة 1: ارفعي الصور الجديدة</h3>
<p>اختاري كل صور الفساتين الجديدة دفعة واحدة — ستُحفظ في مجلد images تلقائياً</p>
<form method="post" enctype="multipart/form-data">
<input type="file" name="images[]" multiple accept="image/*">
<button>رفع الصور</button></form>
</div>

<div class="card">
<h3>📄 الخطوة 2: ارفعي ملف products.js المحدّث</h3>
<p>الملف الموجود في أداة الكتالوج على جهازك بعد إضافة التصاميم الجديدة</p>
<form method="post" enctype="multipart/form-data">
<input type="file" name="datafile" accept=".js">
<button>رفع الملف</button></form>
</div>

<div class="card sync">
<h3 style="color:#D4AF37">⚡ الخطوة 3: مزامنة الموقع</h3>
<p style="color:#c9c3b6">زر واحد يقرأ products.js ويحدّث معرض الموقع تلقائياً</p>
<form method="post"><button type="submit" name="sync">⚡ مزامنة الآن</button></form>
</div>

<div class="card">
<h3>📱 الخطوة 4: حدّثي الكتالوج</h3>
<ol>
<li>افتحي <b>catalog.html</b> من أداة الكتالوج على جهازك</li>
<li>اضغطي <b>تحميل PDF</b> واحفظيه</li>
<li>أرسلي النسخة الجديدة لعملائك عبر واتساب ✓</li>
</ol>
</div>

</div></body></html>
