<?php
require '../config.php';
if (empty($_SESSION['admin'])) { header('Location: login.php'); exit; }
if (isset($_GET['del'])) { $s=$db->prepare("DELETE FROM testimonials WHERE id=?"); $s->bind_param('i',$_GET['del']); $s->execute(); header('Location: testimonials.php'); exit; }
if ($_SERVER['REQUEST_METHOD']==='POST'){
    $n=trim($_POST['customer_name']); $t=trim($_POST['text']); $d=trim($_POST['detail']);
    $s=$db->prepare("INSERT INTO testimonials (customer_name,text,detail) VALUES (?,?,?)");
    $s->bind_param('sss',$n,$t,$d); $s->execute(); header('Location: testimonials.php'); exit;
}
$rows=$db->query("SELECT * FROM testimonials ORDER BY id DESC");
?>
<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>الآراء | المنال كوتور</title><link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;800&display=swap" rel="stylesheet">
<style>
body{font-family:'Tajawal',sans-serif;background:#FAF7F2;margin:0;color:#1A1A1A}
header{background:#1A1A1A;color:#FAF7F2;padding:14px 26px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px}
header a{color:#D4AF37;margin-inline-start:16px;font-size:14px}
.wrap{max-width:900px;margin:auto;padding:34px 20px}
form{background:#fff;border-radius:14px;padding:24px;box-shadow:0 4px 18px rgba(0,0,0,.06);margin-bottom:26px}
input,textarea{width:100%;padding:11px 13px;margin-bottom:12px;border:1px solid #ddd;border-radius:9px;font-family:inherit;font-size:14px}
button{background:#D4AF37;border:none;border-radius:9px;padding:11px 30px;font-family:inherit;font-weight:800;cursor:pointer}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden}
th,td{padding:11px 13px;text-align:right;border-bottom:1px solid #eee;font-size:14px}
th{background:#1A1A1A;color:#D4AF37}
a{color:#c0392b;font-weight:700}
</style></head><body>
<header><div><b>آراء العميلات</b></div>
<div><a href="index.php">الرئيسية</a><a href="products.php">المنتجات</a><a href="logout.php">خروج ⏻</a></div></header>
<div class="wrap">
<form method="post"><h3>إضافة رأي</h3>
<input name="customer_name" placeholder="اسم العميلة" required>
<textarea name="text" placeholder="نص الرأي" required></textarea>
<input name="detail" placeholder="تفصيل (مثال: فستان زفاف)">
<button>إضافة</button></form>
<table><tr><th>#</th><th>الاسم</th><th>الرأي</th><th></th></tr>
<?php while($r=$rows->fetch_assoc()):?>
<tr><td><?=$r['id']?></td><td><?=e($r['customer_name'])?><br><small style="color:#b8963a"><?=e($r['detail'])?></small></td><td><?=e($r['text'])?></td>
<td><a href="?del=<?=$r['id']?>" onclick="return confirm('حذف؟')">حذف</a></td></tr>
<?php endwhile;?></table>
</div></body></html>